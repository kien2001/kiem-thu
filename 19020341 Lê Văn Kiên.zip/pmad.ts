function calcPerimeter(width:number , height: number) : number | string {
    if (width < 0 || height < 0) {
      return "Sorry, width and height must be positive numbers ";
    }
    return 2 * (width + height);
}